#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""选手方案入口（占位示例）。

评测服务通过 run.sh 调用本脚本，固定传入：
    --task <值> --test --out-dir /output

输入：/input（环境变量 DATA_ROOT）下只读挂载的测试数据
输出：把结果写到 --out-dir（=/output）下

本文件仅是「照抄也能跑通」的最小占位，请自行构建你的算法逻辑；
也可完全替换本文件 / 调整目录结构（run.sh 里的入口路径随之修改即可）。
"""
import argparse
import os

DATA_ROOT = os.environ.get("DATA_ROOT", "/input")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", default="all")
    ap.add_argument("--test", action="store_true")
    ap.add_argument("--out-dir", default=os.environ.get("OUTPUT_DIR", "/output"))
    args = ap.parse_args()

    print("输入数据目录 DATA_ROOT =", DATA_ROOT)
    print("输出目录 out_dir =", args.out_dir)
    if os.path.isdir(DATA_ROOT):
        for root, _dirs, files in os.walk(DATA_ROOT):
            for f in files:
                print("  [输入]", os.path.join(root, f))

    os.makedirs(args.out_dir, exist_ok=True)

    # TODO: 在这里读取 /input 数据、运行你的算法、把结果写到 args.out_dir。
    # 不同赛道的输入/输出文件各不相同，请以各赛道题目说明为准。

    # —— 内置大模型调用示例（部分赛道提供，详见 README；是否提供以各赛道题目说明为准）——
    # import requests
    # resp = requests.post(
    #     f"{os.environ['LLM_BASE_URL']}/chat/completions",
    #     headers={"Authorization": f"Bearer {os.environ['LLM_API_KEY']}"},
    #     json={"model": os.environ["LLM_MODEL"],
    #           "messages": [{"role": "user", "content": "……"}]},
    #     timeout=120,
    # )
    # print(resp.json()["choices"][0]["message"]["content"])
    # 用 requests 需在 requirements.txt 加一行：requests

    print("选手方案执行完毕（占位，未产出结果）")


if __name__ == "__main__":
    main()
