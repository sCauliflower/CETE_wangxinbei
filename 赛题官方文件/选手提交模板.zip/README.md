# 选手代码提交模板

本目录是选手提交的**最小可运行模板**。评测服务会按以下流程运行它：

1. 用本目录下的 `Dockerfile` 构建镜像；
2. 以 `bash run.sh --task <值> --test --out-dir /output` 启动容器；
3. 把测试数据只读挂载到 `/input`（环境变量 `DATA_ROOT`）；
4. 把结果写到 `/output`（启动参数 `--out-dir`）。

---

## 一、目录与入口

| 项 | 说明 |
|---|---|
| 镜像构建 | 无需在`Dockerfile`中声明 VOLUME，输入输出文件夹在容器启动命令中挂载
| 固定入口 | `run.sh`（评测服务固定调用它，**文件名与调用方式勿改**） |
| 代码目录 | 可自定；改目录时同步改 `run.sh` 里的 `python3 src/main.py` 这行 |
| 依赖声明 | `requirements.txt`，构建镜像时执行 `pip install -r requirements.txt` |

纯标准库方案 `requirements.txt` 可保持为空（仅注释）。

---

## 二、输入 / 输出

| 项 | 路径 / 变量 |
|---|---|
| 输入数据 | `/input`（环境变量 `DATA_ROOT`，只读） |
| 结果输出 | `/output`（启动参数 `--out-dir`，环境变量 `OUTPUT_DIR`） |

按各赛道题目说明读取 `/input` 下的数据，把作答文件写到 `--out-dir` 即可。

---

## 三、内置大模型（部分赛道提供）

**并非所有赛道都提供内置大模型**，是否提供以**各赛道题目说明**为准。
提供内置模型的赛道，模型（`qwen3.8-27b`）由主办方统一提供，**选手不需要、也不允许自带模型或密钥**，
只读取容器内已注入的环境变量调用。

### 环境变量

| 变量 | 含义 |
|---|---|
| `LLM_BASE_URL` | 模型网关地址（OpenAI 兼容 `/v1`） |
| `LLM_API_KEY` | 本队调用令牌（评测服务自动注入，非真实外网 key） |
| `LLM_MODEL` | 模型名（`qwen3.8-27b`） |
| `LLM_USE_JSON_SCHEMA` | 是否支持 JSON Schema（`1` / `0`） |
| `LLM_ENABLE_THINKING` | 是否开启思考链（`1` / `0`） |

### 调用方式（OpenAI 兼容）

```python
import os
import requests

resp = requests.post(
    f"{os.environ['LLM_BASE_URL']}/chat/completions",
    headers={"Authorization": f"Bearer {os.environ['LLM_API_KEY']}"},
    json={
        "model": os.environ["LLM_MODEL"],
        "messages": [{"role": "user", "content": "……"}],
    },
    timeout=120,
)
print(resp.json()["choices"][0]["message"]["content"])
```

> 用 `requests` 需在 `requirements.txt` 里加一行 `requests`；也可用标准库 `urllib.request`。

要点：

- `model` 填 `LLM_MODEL` 即可，**网关会强制锁定为官方模型**，传别的也会被忽略；
- 支持 `stream: true`（SSE 流式返回）；
- 每队限流 **120 次/分钟**，超限返回 `429`。

### 红线

1. 不写死模型名 / 地址 / key，一律从环境变量读；
2. 不自建 `.env`、不携带任何第三方 API key；
3. 不绕网关直连外部模型平台。

> **评测服务会检测上述违规行为**（写死模型名 / API 地址 / key、直连外部平台、调用非官方模型等），一经发现**该赛道结果判为无效（0 分）**。

---

## 四、提交

把整个目录（`Dockerfile`、`run.sh`、`src/`、`requirements.txt`）打包为 zip 提交即可。
